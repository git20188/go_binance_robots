ALTER TABLE new_symbols ADD expect_price VARCHAR DEFAULT ('0');
