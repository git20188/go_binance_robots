ALTER TABLE futures_positions ADD leverage INTEGER DEFAULT (1);
