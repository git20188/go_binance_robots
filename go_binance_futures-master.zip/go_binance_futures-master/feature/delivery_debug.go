package feature

import (
	"go_binance_futures/feature/api/binance"
)

func GoTestDeliveryAccount() {
	binance.GetDeliveryAccount()
}